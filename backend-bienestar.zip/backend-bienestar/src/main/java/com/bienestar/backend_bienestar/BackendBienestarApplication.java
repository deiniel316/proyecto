package com.bienestar.backend_bienestar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendBienestarApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendBienestarApplication.class, args);
	}

}
